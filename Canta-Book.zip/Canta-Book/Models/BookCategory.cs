﻿namespace Canta_Book.Models
{
    public class BookCategory
    {
        public int CategoryID { get; set; } //PK
        public string CategoryName { get; set; }
    }
}
